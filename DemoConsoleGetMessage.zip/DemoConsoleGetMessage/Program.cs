﻿using NATS.Client;
using System;
using System.Text;
using System.Net.Http;

namespace ConsoleSubscriber
{
    class Program
    {
        static HttpClient client = new HttpClient()
        {
            BaseAddress = new Uri("http://localhost:5000/api/values/")
        };
        static void Main(string[] args)
        {
            Call_Getman();

        }
        /// <summary>
        /// Connecting the Rest API to get the message
        /// </summary>
        static void Call_Getman()
        {
            Console.WriteLine();
            Console.WriteLine("Do you want to read the message using REST GET API ! Press 'y' key ");
            //  Console.ReadLine();
            ConsoleKeyInfo cki = Console.ReadKey();
            if (cki.Key.ToString().ToLower() == "y")
            {
                Console.WriteLine();
                Console.WriteLine("Waiting for new message");

                try
                {
                    //HTTP GET
                    var result = client.GetAsync("ReadMessage").GetAwaiter().GetResult();
                    if (result.IsSuccessStatusCode)
                    {
                        var readTask = result.Content.ReadAsStringAsync();
                        readTask.Wait();
                        Console.WriteLine();
                        Console.WriteLine(readTask.Result);
                        Console.WriteLine();
                        Console.WriteLine("Press 'y' key to continue..");

                    }
                }

                catch (Exception ex)
                {
                    Console.WriteLine("API Connection failed ,  " + ex.Message);
                    Console.WriteLine();
                }

                Call_Getman();
            }
            else
            {
                Console.ReadKey();
            }
        }
    }
}
