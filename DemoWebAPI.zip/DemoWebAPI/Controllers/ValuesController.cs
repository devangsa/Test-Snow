﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using NATS.Client;
using System;
using System.Text;


namespace DemoCore.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ILogger<ValuesController> _logger;

        public ValuesController(ILogger<ValuesController> logger)
        {
            _logger = logger;
        }

        // POST api/<ValuesController>
        [HttpPost]
        public IActionResult Post([FromBody] string value)
        {
            Console.WriteLine($"api/snaphost {value}");
            Console.WriteLine($"Posting message to NATS server as it is a Publisher");
            ConnectionFactory cf = new ConnectionFactory();
            Options opts = ConnectionFactory.GetDefaultOptions();

            opts.Url = "nats://localhost:4222";

            IConnection c = cf.CreateConnection(opts);
            c.Publish("SnowSoftware", Encoding.UTF8.GetBytes($"{value}"));
            c.Close();

            _logger.LogInformation("logged message ");
            return Ok();
        }

        [HttpGet]
        [Route("ReadMessage")]
        //api/values/readmessage
        public object ReadMessage()
        {
            try
            {
                using (var cn = new ConnectionFactory().CreateConnection())
                {
                    /// Subscribing for reading next available message, if needed we can set min timeout for reading
                    var result = cn.SubscribeSync("SnowSoftware");
                    var msg = result.NextMessage();

                    return string.Format("\r\n Subject : {0}  \r\n {1}", msg.Subject, Encoding.UTF8.GetString(msg.Data));
                }
            }
            catch (Exception e)
            {
                return e.Message;
            }
        }
    }
}

