﻿namespace DemoConsoleApp
{
    internal class JavaScriptSerializer
    {
        public JavaScriptSerializer()
        {
        }
    }
}